package com.example.assignment.Department;
import org.springframework.stereotype.Service;

import java.util.*;


@Service
public class DepartmentService {
    public List<Department> getDepartment() {
        List<Department> department = new ArrayList<>();
       department.add(new Department(1, "CSE", 4));
        department.add(new Department(2, "IT", 5));
        department.add(new Department(3, "CSE", 6));
        department.add(new Department(4, "IT", 7));
        return department;
    }
    public void addNewDepartment(Department department) {

        System.out.println(department);
    }
}
