package com.example.assignment.Employee;

import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class EmployeeService {

    public List<Employee> getEmployee() {
        return List.of(
                new Employee(1,
                        "Pranitha",
                        "Avula",
                        4,
                        5,
                        "reddypranitha@gmail.com",
                        2

                )
        );
    }
}
