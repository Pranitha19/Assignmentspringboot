package com.example.assignment.Department;
import com.example.assignment.Exceptions.ApiRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping(path = "api/v1/Department")
public class DepartmentController {
    private final DepartmentService departmentService;

    @Autowired
    public DepartmentController(DepartmentService departmentService) {

        this.departmentService = departmentService;
    }

    @GetMapping
    public List<Department> getDepartment() throws ApiRequestException {
        try {
          return departmentService.getDepartment();
        } catch (Exception e) {
                throw new ApiRequestException("we cannot get all departments");
            }
        }
        @PostMapping
    public void newDepartment(@RequestBody Department department){

        departmentService.addNewDepartment(department);
            if(department.getDepartmentName().isEmpty())
                throw new ApiRequestException("department list is empty");
        }
    }

