package com.example.assignment.jobLevel;

import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class jobLevelService {

    public List<jobLevel> getjobLevel() {
        return List.of(
                new jobLevel(1,
                        "Leveltwo",
                        4000L


                )
        );
    }
}
