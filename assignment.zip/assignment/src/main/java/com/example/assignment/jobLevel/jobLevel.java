package com.example.assignment.jobLevel;
/* <dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-data-jpa</artifactId>
		</dependency> */



// @Entity(name = "joblevel")
public class jobLevel {

    private Integer jobLevelId;
    private String jobLevelname;
    private Long basicPay;

    public jobLevel() {
    }

    public jobLevel(Integer jobLevelId, String jobLevelname, Long basicPay) {
        this.jobLevelId = jobLevelId;
        this.jobLevelname = jobLevelname;
        this.basicPay = basicPay;
    }

    public Integer getJobLevelId() {
        return jobLevelId;
    }

    public void setJobLevelId(Integer jobLevelId) {
        this.jobLevelId = jobLevelId;
    }

    public String getJobLevelname() {
        return jobLevelname;
    }

    public void setJobLevelname(String jobLevelname) {
        this.jobLevelname = jobLevelname;
    }

    public Long getBasicPay() {
        return basicPay;
    }

    public void setBasicPay(Long basicPay) {
        this.basicPay = basicPay;
    }

    @Override
    public String toString() {
        return "jobLevel{" +
                "jobLevelId=" + jobLevelId +
                ", jobLevelname='" + jobLevelname + '\'' +
                ", basicPay=" + basicPay +
                '}';
    }
}
