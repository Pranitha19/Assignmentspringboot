package com.example.assignment.Department;

import com.example.assignment.Exceptions.ApiRequestException;

public class validateDepartment {
    public boolean isValidName(Integer departmentId, String departmentName, Integer departmentNumber) {

        if(departmentName.isEmpty())
            throw new ApiRequestException("Department Name is empty!!");
    else{
        return true;
    }
}

    public boolean validateDepartment(Department department ){
        if((isValidName( department.getDepartmentNumber(),  department.getDepartmentName(),
                department.getDepartmentId()))){
            return true;
        }
        else {
            return false;
        }
    }

    }

