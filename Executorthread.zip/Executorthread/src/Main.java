
package com.apiLimter.demo;



import java.time.LocalDateTime;
import java.util.concurrent.*;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        ExecutorService executorService = Executors.newFixedThreadPool(2);

        CompletableFuture<String> completable1 = CompletableFuture.supplyAsync(()->{
            try {

            } catch (Exception e) {
                throw new IllegalStateException(e);
            }
            return "Hello, this is the first result";


        });
        String result1 = completable1.get();
        System.out.println(result1);

        CompletableFuture<String> completable2 = CompletableFuture.supplyAsync(() -> {
            try {
            } catch (Exception e) {
                throw new IllegalStateException(e);
            }
            return "Holla!, this is the second result";
        });
        System.out.println("calling future 2:" + LocalDateTime.now());
        completable1.join();
        completable2.join();
        String result2 = completable2.get();
        System.out.println(result2);
        System.out.println("calling future 1:" + LocalDateTime.now());
        String combine = Stream.of(completable1, completable2)
                .map(CompletableFuture::join)
                .collect(Collectors.joining(""));
        System.out.println(combine);
        executorService.shutdown();
    }
}


